import java.util.Scanner;

// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {
        Scanner scr = new Scanner(System.in);
        do {
            System.out.println("укажите начало диапазона");
            System.out.println("укажите конец диапазона");
            int num1 = scr.nextInt();
            int num2 = scr.nextInt();
            scr.nextLine();
            int min = Math.min(num1, num2);
            min = min%2 != 0 ? min : min+1;
            int max = Math.min(num1, num2);
            int sum = 0;

            for (int i = min; i <= max; i += 2) {
                sum += i;

            }
            System.out.println(sum);
            System.out.println("введите quit для завершения");
        } while ("quit".equalsIgnoreCase(scr.nextLine()));


    }
}
}