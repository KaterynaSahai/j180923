import java.util.Locale;
import java.util.Scanner;

// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {

    public static void main(String[] args) {
        System.out.println("Введите день недели на англ");
        String userStr = new Scanner(System.in).nextLine();
        DayOfWeek userDay=DayOfWeek.valueOf(userStr.toUpperCase(Locale.ROOT));
        for (DayOfWeek day:DayOfWeek.values()) {
            if(day!=userDay)
                System.out.println(day);




            





        }
    }
}